<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Armada;

class Armadas extends Component
{
    public $armadas, $nomorpolisi, $jenisarmada, $jumlahkursi, $armada_id;
    public $isOpen = 0;

    public function render()
    {
        $this->armadas = Armada::all();
        return view('livewire.armadas');
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }

    private function resetInputFields(){
        $this->nomorpolisi = '';
        $this->jenisarmada = '';
        $this->jumlahkursi = '';
        $this->armada_id = '';
    }

    public function store()
    {
        $this->validate([
        'nomorpolisi' => 'required',
        'jenisarmada' => 'required',
        'jumlahkursi' => 'required',
        ]);
    
        Armada::updateOrCreate(['id' => $this->armada_id], [
        'nomorpolisi' => $this->nomorpolisi,
        'jenisarmada' => $this->jenisarmada,
        'jumlahkursi' => $this->jumlahkursi
        ]);
        
        session()->flash('message',
        $this->armada_id ? 'Armada Updated Successfully.' : 'Armada Created Successfully.');
        
        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $armada = Armada::findOrFail($id);
        $this->armada_id = $id;
        $this->nomorpolisi = $armada->nomorpolisi;
        $this->jenisarmada = $armada->jenisarmada;
        $this->jumlahkursi = $armada->jumlahkursi;
        
        $this->openModal();
    }
    
    public function delete($id)
    {
        Armada::find($id)->delete();
        session()->flash('message', 'Armada Deleted Successfully.');
    }

}
