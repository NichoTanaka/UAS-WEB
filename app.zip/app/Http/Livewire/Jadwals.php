<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Jadwal;
use App\Models\Armada;
use App\Models\Jurusan;
use App\Models\Sopir;
use Illuminate\Support\Facades\DB;

class Jadwals extends Component
{
    public $jadwals, $idsopir, $idarmada, $idjurusan, $hargatiket, $tglberangkat, $jadwal_id;
    public $isOpen = 0;

    

    public function render()
    {
        $this->jadwals = Jadwal::all();
        $this->armadas = Armada::all();
        $this->jurusans = Jurusan::all();
        $this->sopirs = Sopir::all();
        $this->qjadwals = DB::table('jadwal')
            ->join('sopir', 'jadwal.idsopir', '=', 'sopir.id')
            ->join('armada', 'jadwal.idarmada', '=', 'armada.id')
            ->join('jurusan', 'jadwal.idjurusan', '=', 'jurusan.id')
            ->select('jadwal.*', 'sopir.namasopir', 'armada.jenisarmada', 'jurusan.waktukeberangkatan', 'jurusan.kotakeberangkatan', 'jurusan.kotatujuan')
            ->get();
        return view('livewire.jadwals');
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }

    private function resetInputFields(){
        $this->idsopir = '';
        $this->idarmada = '';
        $this->idjurusan = '';
        $this->hargatiket = '';
        $this->tglberangkat = '';
        $this->jadwal_id = '';
    }

    public function store()
    {
        $this->validate([
        'idsopir' => 'required',
        'idarmada' => 'required',
        'idjurusan' => 'required',
        'hargatiket' => 'required',
        'tglberangkat' => 'required',
        ]);
    
        Jadwal::updateOrCreate(['id' => $this->jadwal_id], [
        'idsopir' => $this->idsopir,
        'idarmada' => $this->idarmada,
        'idjurusan' => $this->idjurusan,
        'hargatiket' => $this->hargatiket,
        'tglberangkat' => $this->tglberangkat
        ]);
        
        session()->flash('message',
        $this->jadwal_id ? 'Jadwal Updated Successfully.' : 'Jadwal Created Successfully.');
        
        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $jadwal = Jadwal::findOrFail($id);
        $this->jadwal_id = $id;
        $this->idsopir = $jadwal->idsopir;
        $this->idarmada = $jadwal->idarmada;
        $this->idjurusan = $jadwal->idjurusan;
        $this->hargatiket = $jadwal->hargatiket;
        $this->tglberangkat = $jadwal->tglberangkat;
        
        $this->openModal();
    }
    
    public function delete($id)
    {
        Jadwal::find($id)->delete();
        session()->flash('message', 'Jadwal Deleted Successfully.');
    }

}
