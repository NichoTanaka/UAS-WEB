<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Jurusan;

class Jurusans extends Component
{
    public $jurusans, $kotakeberangkatan, $kotatujuan, $waktukeberangkatan, $hargatiket, $jurusan_id;
    public $isOpen = 0;

    public function render()
    {
        $this->jurusans = Jurusan::all();
        return view('livewire.jurusans');
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }

    private function resetInputFields(){
        $this->kotakeberangkatan = '';
        $this->kotatujuan = '';
        $this->waktukeberangkatan = '';
        $this->hargatiket = '';
        $this->jurusan_id = '';
    }

    public function store()
    {
        $this->validate([
        'kotakeberangkatan' => 'required',
        'kotatujuan' => 'required',
        'waktukeberangkatan' => 'required',
        'hargatiket' => 'required',
        ]);
    
        Jurusan::updateOrCreate(['id' => $this->jurusan_id], [
        'kotakeberangkatan' => $this->kotakeberangkatan,
        'kotatujuan' => $this->kotatujuan,
        'waktukeberangkatan' => $this->waktukeberangkatan,
        'hargatiket' => $this->hargatiket
        ]);
        
        session()->flash('message',
        $this->jurusan_id ? 'Jurusan Updated Successfully.' : 'Jurusan Created Successfully.');
        
        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $jurusan = Jurusan::findOrFail($id);
        $this->jurusan_id = $id;
        $this->kotakeberangkatan = $jurusan->kotakeberangkatan;
        $this->kotatujuan = $jurusan->kotatujuan;
        $this->waktukeberangkatan = $jurusan->waktukeberangkatan;
        $this->hargatiket = $jurusan->hargatiket;
        
        $this->openModal();
    }
    
    public function delete($id)
    {
        Jurusan::find($id)->delete();
        session()->flash('message', 'Jurusan Deleted Successfully.');
    }

}
