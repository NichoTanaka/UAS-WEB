<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Booking;
use App\Models\Jadwal;
use Illuminate\Support\Facades\DB;

class Bookings extends Component
{
    public $bookings, $idsopir, $idarmada, $idjurusan, $hargatiket, $tglberangkat, $booking_id;
    public $isOpen = 0;

    

    public function render()
    {
        $this->bookings = Booking::all();
        $this->qjadwals = DB::table('jadwal')
            ->join('sopir', 'jadwal.idsopir', '=', 'sopir.id')
            ->join('armada', 'jadwal.idarmada', '=', 'armada.id')
            ->join('jurusan', 'jadwal.idjurusan', '=', 'jurusan.id')
            ->select('jadwal.*', 'sopir.namasopir', 'armada.jenisarmada', 'jurusan.waktukeberangkatan', 'jurusan.kotakeberangkatan', 'jurusan.kotatujuan')
            ->get();
        return view('livewire.bookings');
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }

    private function resetInputFields(){
        $this->idsopir = '';
        $this->idarmada = '';
        $this->idjurusan = '';
        $this->hargatiket = '';
        $this->tglberangkat = '';
        $this->booking_id = '';
    }


    public function store()
    {
        $this->validate([
        'idjadwal' => 'required',
        'iduser' => 'required',
        'jumlahpenumpang' => 'required',
        'hargatotal' => 'hargatotal',
        'nomorbooking' => 'nomorbooking',
        'namalengkap' => 'namalengkap',
        'noktp' => 'noktp',
        'tempatjemput' => 'tempatjemput',
        'nomorkursi' => 'nomorkursi',
        ]);
    
        Booking::updateOrCreate(['id' => $this->booking_id], [
        'idjadwal' => $this->idjadwal,
        'iduser' => $this->iduser,
        'jumlahpenumpang' => $this->jumlahpenumpang,
        'hargatotal' => $this->hargatotal,
        'nomorbooking' => $this->nomorbooking,
        'namalengkap' => $this->namalengkap,
        'noktp' => $this->noktp,
        'tempatjemput' => $this->tempatjemput,
        'nomorkursi' => $this->nomorkursi,
        'statusbooking' => $this->statusbooking
        ]);
        
        session()->flash('message', $this->booking_id ? 'Jadwal Updated Successfully.' : 'Jadwal Created Successfully.');
        
        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $booking = Booking::findOrFail($id);
        $this->booking_id = $id;
        $this->idsopir = $booking->idsopir;
        $this->idarmada = $booking->idarmada;
        $this->idjurusan = $booking->idjurusan;
        $this->hargatiket = $booking->hargatiket;
        $this->tglberangkat = $booking->tglberangkat;
        
        $this->openModal();
    }
    

}
