<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Sopir;

class Sopirs extends Component
{
    public $sopirs, $namasopir, $nomorsim, $phone, $alamat, $sopir_id;
    public $isOpen = 0;

    public function render()
    {
        $this->sopirs = Sopir::all();
        return view('livewire.sopirs');
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }

    private function resetInputFields(){
        $this->namasopir = '';
        $this->nomorsim = '';
        $this->phone = '';
        $this->alamat = '';
        $this->sopir_id = '';
    }

    public function store()
    {
        $this->validate([
        'namasopir' => 'required',
        'nomorsim' => 'required',
        'phone' => 'required',
        'alamat' => 'required',
        ]);
    
        Sopir::updateOrCreate(['id' => $this->sopir_id], [
        'namasopir' => $this->namasopir,
        'nomorsim' => $this->nomorsim,
        'phone' => $this->phone,
        'alamat' => $this->alamat
        ]);
        
        session()->flash('message',
        $this->sopir_id ? 'Sopir Updated Successfully.' : 'Sopir Created Successfully.');
        
        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $sopir = Sopir::findOrFail($id);
        $this->sopir_id = $id;
        $this->namasopir = $sopir->namasopir;
        $this->nomorsim = $sopir->nomorsim;
        $this->phone = $sopir->phone;
        $this->alamat = $sopir->alamat;
        
        $this->openModal();
    }
    
    public function delete($id)
    {
        Sopir::find($id)->delete();
        session()->flash('message', 'Sopir Deleted Successfully.');
    }

}
