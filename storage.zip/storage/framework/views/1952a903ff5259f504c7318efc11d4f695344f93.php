

<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            <?php if(session()->has('message')): ?>
            <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                <div class="flex">
                    <div>
                        <p class="text-sm"><?php echo e(session('message')); ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            
            <?php if($isOpen): ?>
                <?php echo $__env->make('livewire.createjadwal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <table class="table-fixed w-full">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 w-20">No.</th>
                        <th class="px-4 py-2">Sopir</th>
                        <th class="px-4 py-2">Armada</th>
                        <th class="px-4 py-2">Jurusan</th>
                        <th class="px-4 py-2">Tanggal Keberangkatan</th>
                        <th class="px-4 py-2">Jam Keberangkatan</th>
                        <th class="px-4 py-2">Harga Tiket</th>
                        <th class="px-4 py-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $qjadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($jadwal->id); ?></td>
                        <td class="border px-4 py-2"><?php echo e($jadwal->namasopir); ?></td>
                        <td class="border px-4 py-2"><?php echo e($jadwal->jenisarmada); ?></td>
                        <td class="border px-4 py-2"><?php echo e($jadwal->kotakeberangkatan); ?> to <?php echo e($jadwal->kotatujuan); ?></td>
                        <td class="border px-4 py-2"><?php echo e($jadwal->tglberangkat); ?></td>
                        <td class="border px-4 py-2"><?php echo e($jadwal->waktukeberangkatan); ?></td>
                        <td class="border px-4 py-2"><?php echo e($jadwal->hargatiket); ?></td>
                        <td class="border px-4 py-2">
                            <button wire:click="edit(<?php echo e($jadwal->id); ?>)" class="bg-blue-500 hover:bg-blue-700 text-black font-bold py-2 px-4 rounded"><font color="blue">Booking</font></button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\Users\ACER\eticketing\resources\views/livewire/bookings.blade.php ENDPATH**/ ?>