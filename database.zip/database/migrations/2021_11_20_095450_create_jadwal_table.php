<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateJadwalTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jadwal', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('idsopir');
            $table->unsignedBigInteger('idarmada');
            $table->unsignedBigInteger('idjurusan');
            $table->date('tglberangkat');
            $table->decimal('hargatiket');
            $table->timestamps();

            
            $table->foreign('idsopir')->references('id')->on('sopir')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('idarmada')->references('id')->on('armada')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('idjurusan')->references('id')->on('jurusan')->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jadwal');
    }
}
