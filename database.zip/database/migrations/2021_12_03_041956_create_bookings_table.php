<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBookingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('idjadwal');
            $table->unsignedBigInteger('iduser');
            $table->integer('jumlahpenumpang');
            $table->decimal('hargatotal');
            $table->string('statusbooking');
            $table->string('nomorbooking');
            $table->string('namalengkap');
            $table->string('noktp');
            $table->string('tempatjemput');
            $table->string('nomorkursi');
            $table->timestamps();

            $table->foreign('idjadwal')->references('id')->on('jadwal')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('iduser')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bookings');
    }
}
