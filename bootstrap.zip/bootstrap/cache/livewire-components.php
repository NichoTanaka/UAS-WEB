<?php return array (
  'armadas' => 'App\\Http\\Livewire\\Armadas',
  'blogs' => 'App\\Http\\Livewire\\Blogs',
  'bookings' => 'App\\Http\\Livewire\\Bookings',
  'jadwals' => 'App\\Http\\Livewire\\Jadwals',
  'jurusans' => 'App\\Http\\Livewire\\Jurusans',
  'sopirs' => 'App\\Http\\Livewire\\Sopirs',
);