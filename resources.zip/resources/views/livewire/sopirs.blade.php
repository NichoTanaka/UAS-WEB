

<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
            @if (session()->has('message'))
            <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
                <div class="flex">
                    <div>
                        <p class="text-sm">{{ session('message') }}</p>
                    </div>
                </div>
            </div>
            @endif
            
            <button wire:click="create()" class="bg-blue-500 hover:bg-blue-700 text-black font-bold py-2 px-4 rounded my-3">Create New Sopir</button>
            @if($isOpen)
                @include('livewire.createsopir')
            @endif
            <table class="table-fixed w-full">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 w-20">No.</th>
                        <th class="px-4 py-2">Nama Sopir</th>
                        <th class="px-4 py-2">Nomor SIM</th>
                        <th class="px-4 py-2">Phone</th>
                        <th class="px-4 py-2">Alamat</th>
                        <th class="px-4 py-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($sopirs as $sopir)
                    <tr>
                        <td class="border px-4 py-2">{{ $sopir->id }}</td>
                        <td class="border px-4 py-2">{{ $sopir->namasopir }}</td>
                        <td class="border px-4 py-2">{{ $sopir->nomorsim }}</td>
                        <td class="border px-4 py-2">{{ $sopir->phone }}</td>
                        <td class="border px-4 py-2">{{ $sopir->alamat }}</td>
                        <td class="border px-4 py-2">
                            <button wire:click="edit({{ $sopir->id }})" class="bg-blue-500 hover:bg-blue-700 text-black font-bold py-2 px-4 rounded">Edit</button>
                            <button wire:click="delete({{ $sopir->id }})" class="bg-red-500 hover:bg-red-700 text-black font-bold py-2 px-4 rounded">Delete</button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>