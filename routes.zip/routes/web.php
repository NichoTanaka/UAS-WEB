<?php

use Illuminate\Support\Facades\Route;
use App\Http\Livewire\Blogs;
use App\Http\Livewire\Sopirs;
use App\Http\Livewire\Armadas;
use App\Http\Livewire\Jurusans;
use App\Http\Livewire\Jadwals;
use App\Http\Livewire\Bookings;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::middleware(['auth:sanctum', 'verified'])->group(function () {
    Route::get('blog', Blogs::class)->name('blog');
    Route::get('sopir', Sopirs::class)->name('sopir');
    Route::get('armada', Armadas::class)->name('armada');
    Route::get('jurusan', Jurusans::class)->name('jurusan');
    Route::get('jadwal', Jadwals::class)->name('jadwal');
    Route::get('booking', Bookings::class)->name('booking');
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
}); 
